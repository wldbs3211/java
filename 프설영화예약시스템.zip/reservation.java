package ��ȭ����ý���;

public class reservation {

	private int col,row;
	private boolean[][] seats;
	public reservation(int i,int j)
	{
		col =i;
		row = j;
		seats=new boolean[col][row];
		for(int i1=0;i1<col;i1++)
		{
			for(int j1=0;j1<row;j1++)
				{
				seats[i1][j1]=false;
				}
		}
	}
	public boolean getSeats(int i, int j)
	{
		return seats[i][j];
	}
	public void res(int i,int j)
	{

		seats[i][j]=true;
	}
	
	public void cancel(int i, int j)
	{
		
		seats[i][j]=false;
	}
	
	public void print()
	{
		for(int i=0;i<col;i++)
		{
			for(int j=0;j<row;j++)
				{if (seats[i][j] == true)
					System.out.print("��");
				else
					System.out.print("��");
				}
		System.out.println();
		}
		
	}
}

