package ��������;

public class Graduate extends Student { //���п���
	protected String major;

	public Graduate(String studentNum,String process,String name, int grade, String professorName,String address, double score,String major) {
		super(studentNum,process,name, grade, professorName, address,score);
		this.major = major;
		
	}
	public Graduate(String studentNum,String process,String name, int grade, String professorName,String address, double score) {
		super(studentNum,process,name, grade, professorName, address,score);
		
	}
	public void changeMajor(String newMajor) throws MyException {
		if (newMajor.equals("")) {
			throw new MyException(-100, "Major Name - Empty Error");
		} else {
			major=newMajor;
		}
	}

	public void show() {
	if(major.equals(""))
	{
		System.out.print("�й�: "+studentNum+", ����: "+process+", ���� : "+name+", �г� : "+grade+", �������� : "+professorName+", �ּ� : "+address+", ����: "+score);
	}
	else
	{
		System.out.print("�й�: "+studentNum+", ����: "+process+", ���� : "+name+", �г� : "+grade+", �������� : "+professorName+", �ּ� : "+address+", ����: "+score+", �����о� : " + major);
	}
	}
	public String fStudent()
	{
		String temp;
		if(!major.equals(""))
		{
			temp = studentNum + ", "+ process + ", "+ name+ ", "+ grade 
			+ ", "+ professorName + ", "+ address + ", "+ score + ", "+ major;
		}
		else 
		{
			temp = studentNum + ", "+ process + ", "+ name+ ", "+ grade 
					+ ", "+ professorName + ", "+ address + ", "+ score;
		}
		return temp;
	}
}

