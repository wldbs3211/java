package ��������;

public class MyException extends Exception{
	private int code;
	private String description;
	
	public MyException()
	{
		code=0;
		description="";
	}
	public MyException(int code,String desciption)
	{
		this.code=code;
		this.description=description;
	}
	public int getCode()
	{
		return code;
	}
	public String getDescription()
	{
		
		return description;
	}
}
