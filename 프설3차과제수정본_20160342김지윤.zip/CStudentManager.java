package ��������;

import java.io.IOException;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;

public class CStudentManager {

	private Student[] sl = new Student[100];
	private int count = 0;

	void loadStudentFile(String fileName) throws IOException {

		FileInputStream fis = new FileInputStream(fileName);
		InputStreamReader isr = new InputStreamReader(fis);
		BufferedReader br = new BufferedReader(isr);

		String str;
		String[] strArr;

		while ((str = br.readLine()) != null) {
			strArr = str.split(", ");
			String s_n = strArr[0];
			String pr = strArr[1];
			String na = strArr[2];
			int gr = Integer.parseInt(strArr[3]);
			String p_n = strArr[4];
			String ad = strArr[5];
			double sc = Double.parseDouble(strArr[6]);

			if (strArr.length == 7) {
				insertStudent(s_n, pr, na, gr, p_n, ad, sc);

			} else if (strArr.length == 8) {
				String ci = strArr[7];

				insertStudent(s_n, pr, na, gr, p_n, ad, sc, ci);

			} else if (strArr.length == 10) {
				String co = strArr[7];
				String de = strArr[8];
				String po = strArr[9];

				insertStudent(s_n, pr, na, gr, p_n, ad, sc,"", co, de, po);

			}
			
			else if (strArr.length == 11) {
				String ma = strArr[7];
				String co = strArr[8];
				String de = strArr[9];
				String po = strArr[10];

				insertStudent(s_n, pr, na, gr, p_n, ad, sc, ma, co, de, po);

			}
		}

		isr.close();
		br.close();
	}

	void saveStudentFile(String fileName) throws IOException {
		FileWriter fw = new FileWriter(fileName);
		BufferedWriter bw = new BufferedWriter(fw);

		for (int i = 0; i < count; i++) {
			String temp = sl[i].fStudent();
			bw.write(temp);
			bw.newLine();
		}

		bw.close();
	}

	public void insertStudent(String s_n, String pr, String na, int gr, String p_n, String ad, double sc, String ci) {
		if (pr.equals("�к�"))
			sl[count++] = new Under(s_n, pr, na, gr, p_n, ad, sc, ci);

		else if (pr.equals("���п�"))
			sl[count++] = new Graduate(s_n, pr, na, gr, p_n, ad, sc, ci);

		else
			return;
	}

	public void insertStudent(String s_n, String pr, String na, int gr, String p_n, String ad, double sc) {
		if (pr.equals("�к�"))
			sl[count++] = new Under(s_n, pr, na, gr, p_n, ad, sc, "");

		else if (pr.equals("���п�"))
			sl[count++] = new Graduate(s_n, pr, na, gr, p_n, ad, sc, "");

		else
			return;
	}

	public void insertStudent(String s_n, String pr, String na, int gr, String p_n, String ad, double sc, String ma,
			String co, String de, String po) {
		sl[count++] = new IndustryGraduate(s_n, pr, na, gr, p_n, ad, sc, ma, co, de, po);
	}

	public void insertStudent(String s_n, String pr, String na, int gr, String p_n, String ad, double sc, String co,
			String de, String po) {
		sl[count++] = new IndustryGraduate(s_n, pr, na, gr, p_n, ad, sc, "", co, de, po);
	}

	public void deleteStudent(String studentID) {
		
		for (int i = 0; i < count; i++) {
			if (sl[i].studentNum.equals(studentID)) {
				for (int j = i; j < count; j++) {
					sl[j] = sl[j + 1];
				}
				count--;
				break;
			} else if (sl[i].studentNum != studentID && i == count - 1) {
				System.out.println("ID�� Ȯ���Ͻʽÿ�.(���� ���̵�)");
				break;
			}
		}

	}
	

	public void sortByGPA() {

		for (int i = 0; i < count; i++) {

			if (i + 1 == count) // ������ ���� print
			{
				sl[count - 1].show();
				System.out.println();
				break;
			}
			for (int j = i + 1; j < count; j++) { // ������ ������ print
				if (sl[i].score < sl[j].score) {
					Student temp = sl[j];
					sl[j] = sl[i];
					sl[i] = temp;
				}

			}
			sl[i].show();
			System.out.println();
		}
	}

	public void searchByAdvisor(String advisorName) {
		for (int i = 0; i < count; i++) {
			if (sl[i].professorName.equals(advisorName)) {
				sl[i].show();
				System.out.println();
			}
		}
	}

	public void printStudent() {
		for (int i = 0; i < count; i++) {
			sl[i].show();
			System.out.println();
		}
	}

	public void clearAll() {
		for (int i = 0; i <= count; i++) {
			sl[i].studentNum = null;
			count = 0;
		}
	}
}
