package ��������;

public class IndustryGraduate extends Graduate implements Employee{ //������п���
	private Employee2 em;
 
	public IndustryGraduate(String studentNum,String process,String name, int grade, String professorName, String address,double score, String major, String company,String department,String position)
	{
		super(studentNum,process,name, grade, professorName, address,score,major);
		em = new Employee2(name,company,department,position);
		
	}
	public IndustryGraduate(String studentNum,String process,String name, int grade, String professorName, String address,double score, String company,String department,String position)
	{
		super(studentNum,process,name, grade, professorName, address,score);
		em = new Employee2(name,company,department,position);
		
	}
	public void show()
	{
		if(major.equals(""))
		{
			System.out.print("�й�: "+studentNum+", ����: "+process+", ���� : "+name+", �г� : "+grade+", �������� : "+professorName+", �ּ� : "+address+", ����: "+score+",\n\t              ȸ�� : "+em.company+", �μ� : "+em.department+", ��å : "+em.position);	
		}
	else
		System.out.print("�й�: "+studentNum+", ����: "+process+", ���� : "+name+", �г� : "+grade+", �������� : "+professorName+", �ּ� : "+address+", ����: "+score+", �����о� : " + major+",\n\t              ȸ�� : "+em.company+", �μ� : "+em.department+", ��å : "+em.position);
	}
	@Override
	public void changePosition(String newPosition) throws MyException {
		// TODO Auto-generated method stub
		em.changePosition(newPosition);
	}
	public String fStudent()
	{
		String temp;
		if(!major.equals(""))
		{
			temp = studentNum + ", "+ process + ", "+ name+ ", "+ grade 
			+ ", "+ professorName + ", "+ address + ", "+ score + ", "+ major+", "+ em.company + ", "+ em.department + ", "+ em.position;
		}
		else 
		{
			temp = studentNum + ", "+ process + ", "+ name+ ", "+ grade 
					+ ", "+ professorName + ", "+ address + ", "+ score + ", "+ em.company + ", "+ em.department + ", "+ em.position;
		}
		return temp;
	}
}
