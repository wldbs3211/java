package ��������;

public class Under extends Student{ //�кλ�
	private String circle; // ���Ƹ�
	
	public Under(String studentNum,String process,String name, int grade, String professorName,String address,double score, String circle) {
		super(studentNum,process,name, grade, professorName, address,score);
		this.circle = circle;
		
	}
	public Under(String studentNum,String process,String name, int grade, String professorName,String address,double score) {
		super(studentNum,process,name, grade, professorName, address,score);
		
	}
	public void ChangeCircle(String newCircle)throws MyException
	{
		if(newCircle.equals(""))
		{
			throw new MyException(-200,"Circle Name - Empty Error");
		}
		else{
		circle = newCircle;
		}
	}
	
	public void show()
	{
		if(circle.equals(""))
		{
		System.out.print("�й�: "+studentNum+", ����: "+process+", ���� : "+name+", �г� : "+grade+", �������� : "+professorName+", �ּ� : "+address+", ����: "+score);
		}
		else 
		{
			System.out.print("�й�: "+studentNum+", ����: "+process+", ���� : "+name+", �г� : "+grade+", �������� : "+professorName+", �ּ� : "+address+", ����: "+score+", ���Ƹ� : " + circle);
			}
	}

	public String fStudent()
	{
		String temp;
		if(!circle.equals(""))
		{
			temp = studentNum + ", "+ process + ", "+ name+ ", "+ grade 
			+ ", "+ professorName + ", "+ address + ", "+ score + ", "+ circle;
		}
		else 
		{
			temp = studentNum + ", "+ process + ", "+ name+ ", "+ grade 
					+ ", "+ professorName + ", "+ address + ", "+ score;
		}
		return temp;
	}
}
