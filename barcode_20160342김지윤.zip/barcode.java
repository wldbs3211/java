package ����;

import java.util.*;

public class barcode {

   int ������ȣ;
   barcode(){������ȣ = 0;}
   void input() {
      int num;
      System.out.print("������ȣ�� �Է��ϼ��� : ");
      Scanner sc = new Scanner(System.in);
      num = sc.nextInt();
      ������ȣ = num;
   }

   void print() {
      int ������ȣcopy = ������ȣ;
      int num =10000;
      int result = 0;
      for(int i = 0; i < 5 ; i++) {
         result = ������ȣcopy / num;
         ������ȣcopy = ������ȣcopy % num;
         num = num/10;
         switch (result) {
         case 0:
            System.out.print("|||| ");break;
         case 1:
            System.out.print("|  ||");break;
         case 2:
            System.out.print("  | |");break;
         case 3:
            System.out.print("  || ");break;
         case 4:
            System.out.print(" |  |");break;
         case 5:
            System.out.print(" | | ");break;
         case 6:
            System.out.print(" ||  ");break;
         case 7:
            System.out.print("|   |");break;
         case 8:
            System.out.print("|  | ");break;
         case 9:
            System.out.print("| |  ");break;
         }
      }
   }
   
   public static void main(String[] args)
   {
      barcode b = new barcode();
      b.input();
      b.print();
      System.out.println();
      b.print();
      System.out.println();
      System.out.println("|||||||||||||||||||||||||");
      System.out.println("|||||||||||||||||||||||||");
   }
}