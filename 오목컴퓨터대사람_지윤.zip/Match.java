package ����_�������;

import java.util.Scanner;

public class Match {
	protected Player[] players = new Player[3]; // �÷��̾� �迭
	protected int turn = 1; // ���� �÷��̾��ȣ
	protected int order = 0;
	private int playType; // ����Ÿ��
	protected OmokBoard playBoard; // �ٵ���
	protected int boardSize = 0; // 0�̸� 10*10, 1�̸� 15*15, 2�̸� 19*19

	public Match() {
		int size = boardSize();
		playBoard = new OmokBoard(size, size);
		MyMatch game = new MyMatch(size, size);

		game.registerPlayers();
		game.start();
	}

	public Match(int rows, int cols) {
		playBoard = new OmokBoard(rows, cols);
	}

	public int boardSize() {

		Scanner s = new Scanner(System.in);
		System.out.print("������ ũ�� ����(0: 10*10, 1: 15*15, 2: 19*19) �� �����ϼ���. : ");
		boardSize = s.nextInt();
		while (true) {
			switch (boardSize) {
			case 0:
				return 11;
			case 1:
				return 16;
			case 2:
				return 20;
			default:
				System.out.println("0 �Ǵ� 1 �Ǵ� 2 �� �����ϼ���.");
				continue;
			}
		}
	}

	private boolean checkWinningCondition(Position m) { // ���� ���� �Ǵ�

		int[] stoneNum = new int[8];

		playBoard.countSameColorStones(m, playBoard.getStone(m.getRow(), m.getColumn()), stoneNum);

		if (stoneNum[0] + stoneNum[4] >= 4 || stoneNum[1] + stoneNum[5] >= 4 || stoneNum[2] + stoneNum[6] >= 4
				|| stoneNum[3] + stoneNum[7] >= 4)
			return true;
		else
			return false;
	}

	private boolean checkValidity(Position m) { // ���� ���� �� �ִ� �ڸ����� �˻�

		if (playBoard.getStone(m.getRow(), m.getColumn()) == StoneType.None)
			return true;
		else
			return false;
	}

	public int getTurn() {
		return turn;
	}

	public void setTurn(int n) {
		turn = n;
	}

	public Player getPlayer(int n) {
		return players[n];

	}

	public Player getCurrentPlayer() {
		return players[turn];
	}

	public StoneType getCurrentColor() {
		if (turn == 1)
			return StoneType.White;
		else
			return StoneType.Black;
	}

	public OmokBoard getBoard() {
		return playBoard;

	}

	public void setBoard(OmokBoard board) {
		playBoard = board;
	}

	public void setPlayer(int n, Player player) {
		players[n] = player;
	}

	public int getPlayerType() {
		return playType;

	}

	public void setPlayerType(int n) {
		playType = n;
	}

}