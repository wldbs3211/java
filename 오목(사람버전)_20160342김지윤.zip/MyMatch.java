package ����_�������;

import java.util.Scanner;

public class MyMatch extends Match {
	public MyMatch(int rows, int cols) {
		super(rows, cols);
	}

	public boolean checkWinningCondition(Position m) { // ���� ���� �Ǵ�

		int[] stoneNum = new int[8];

		playBoard.countSameColorStones(m, playBoard.getStone(m.getRow(), m.getColumn()), stoneNum);

		if (stoneNum[0] + stoneNum[4] >= 4 || stoneNum[1] + stoneNum[5] >= 4 || stoneNum[2] + stoneNum[6] >= 4
				|| stoneNum[3] + stoneNum[7] >= 4)
			return true;
		else
			return false;
	}

	public boolean checkValidity(Position m) { // ���� ���� �� �ִ� �ڸ����� �˻�

		if (playBoard.getStone(m.getRow(), m.getColumn()) == StoneType.None)
			return true;
		else
			return false;
	}

	public void registerPlayers() { //players ���
		System.out.println("player VS player");

		Scanner s = new Scanner(System.in);
		String name = "";
		System.out.println("* player1 ��� *");
		System.out.print("�̸� : ");
		name = s.next();

		players[1] = new MyPlayer(1, name, 100, 1);

		System.out.println("* player2 ��� *");
		System.out.print("�̸� : ");
		name = s.next();
		players[2] = new MyPlayer(2, name, 100, 2);

	}

	public void display() { //������ ���� �� �� ����

		System.out.print(" ");
		for (int i = 0; i < playBoard.getRowCount(); i++) {
			if (i == 0) {
				for (int n = 0; n < playBoard.getColCount(); n++) {
					System.out.print(n + " ");
				}
				System.out.println();
				System.out.print("0");
			} else
				System.out.print(i);
			for (int j = 0; j < playBoard.getColCount(); j++) {
				if (playBoard.getStone(i, j) == StoneType.None)
					System.out.print(" ");
				
				else if (playBoard.getStone(i, j) == StoneType.Black)
					System.out.print("��");
				
				else
					System.out.print("��");
				
				if(j >= 10)
					System.out.print("  ");
				
				else
					System.out.print(" ");
			}
			System.out.println();
		}

	}

	public void start() { //������� ����
		playBoard.clear();
		while (true) {
			display();

			Position m = (players[turn]).play(playBoard);

			if (checkValidity(m)) {
				playBoard.putStone(m.getRow(), m.getColumn(), getCurrentColor());
				if (checkWinningCondition(m)) {
					display();
					System.out.println("[player" + turn + "] " + players[turn].getName() + "����  �¸��Դϴ�!");
					break;
				}
				if (turn == 1)
					turn = 2;
				else
					turn = 1;

			} else {
				System.out.println("<���� �� �� ���� ��ǥ �Դϴ�.>");
				continue;
			}

		}
	}
}
