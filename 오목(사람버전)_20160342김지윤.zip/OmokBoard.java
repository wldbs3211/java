package ����_�������;

public class OmokBoard {

	private int Rows;
	private int Cols;
	private StoneType[][] matrix = new StoneType[Rows][Cols];

	public OmokBoard() {
		// TODO Auto-generated constructor stub
		matrix = new StoneType[20][20];
	}

	public OmokBoard(int rows, int cols) {
		Rows = rows;
		Cols = cols;
		matrix = new StoneType[rows][cols];
	}

	public void putStone(int x, int y, StoneType stone) {
		matrix[x][y] = stone;
	}

	public void removeStone(int x, int y) {
		matrix[x][y] = StoneType.None;
	}

	public StoneType getStone(int x, int y) {
		if (x < 0 || y < 0)
			return null;
		else if (x >= Rows || y >= Cols)
			return null;
		else
			return matrix[x][y];
	}

	public void clear() {
		for (int i = 0; i < Rows; i++)
			for (int j = 0; j < Cols; j++)
				matrix[i][j] = StoneType.None;
	}

	public int getRowCount() {
		return Rows;
	}

	public int getColCount() {
		return Cols;
	}

	public void countSameColorStones(Position m, StoneType color, int[] stoneNum) { //�ȹ���
		for(int i = 1 ; i < Rows ; i++) //��
		{
			if(getStone(m.getRow() - i, m.getColumn()) == color)
				stoneNum[0]++;
			else break;
		}
		for(int i = 1 ; i < Rows ; i++) //�ϵ�
		{
			if(getStone(m.getRow() - i, m.getColumn() +i) == color)
				stoneNum[1]++;
			else break;
		}
		for(int i = 1 ; i < Rows ; i++) //��
		{
			if(getStone(m.getRow(), m.getColumn() +i) == color)
				stoneNum[2]++;
			else break;
		}
		for(int i = 1 ; i < Rows ; i++) //����
		{
			if(getStone(m.getRow()+i, m.getColumn() +i) == color)
				stoneNum[3]++;
			else break;
		}
		for(int i = 1 ; i < Rows ; i++) //��
		{
			if(getStone(m.getRow()+i, m.getColumn()) == color)
				stoneNum[4]++;
			else break;
		}
		for(int i = 1 ; i < Rows ; i++) //����
		{
			if(getStone(m.getRow()+i, m.getColumn()-i) == color)
				stoneNum[5]++;
			else break;
		}
		for(int i = 1 ; i < Rows ; i++) //��
		{
			if(getStone(m.getRow(), m.getColumn()-i) == color)
				stoneNum[6]++;
			else break;
		}
		for(int i = 1 ; i < Rows ; i++) //�ϼ�
		{
			if(getStone(m.getRow()-i, m.getColumn()-i) == color)
				stoneNum[7]++;
			else break;
		}
	}
	}

