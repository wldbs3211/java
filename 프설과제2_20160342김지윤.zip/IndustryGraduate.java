package ��������;

public class IndustryGraduate extends Graduate implements Employee{
	private Employee2 em;
 
	public IndustryGraduate(String name, int grade, String professorName, String address, String major, String company,String department,String position)
	{
		super(name, grade, professorName, address,major);
		em = new Employee2(name,company,department,position);
		
	}
	public void show()
	{
		super.show();
		System.out.print(", ȸ�� : "+em.company+", �μ� : "+em.department+", ��å : "+em.position);
	}
	@Override
	public void changePosition(String newPosition) throws MyException {
		// TODO Auto-generated method stub
		em.changePosition(newPosition);
	}
	
}
