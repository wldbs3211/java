package ��������;

public class Student {
	protected String name;
	protected int grade;
	protected String professorName;
	protected String address;
	
	public Student(String name, int grade, String professorName,String address)
	{
		this.name = name;
		this.grade = grade;
		this.professorName = professorName;
		this.address = address;
	}
	public String getAddress()
	{
		return address;
	}
	
	public void changeAddress(String newAddress)
	{
		address=newAddress;
	}
	
	public void show()
	{
		System.out.print("���� : "+name+", �г� : "+grade+", �������� : "+professorName+", �ּ� : "+address);
		
	}
}
