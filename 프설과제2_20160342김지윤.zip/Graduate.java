package ��������;

public class Graduate extends Student {
	protected String major;

	public Graduate(String name, int grade, String professorName,String address, String major) {
		super(name, grade, professorName, address);
		this.major = major;
		
	}
	
	public void changeMajor(String newMajor) throws MyException {
		if (newMajor.equals("")) {
			throw new MyException(-100, "Major Name - Empty Error");
		} else {
			major=newMajor;
		}
	}

	public void show() {
		System.out.print("���� : ���п�, ");
		super.show();
		System.out.print(", �����о� : " + major);
	}
}
