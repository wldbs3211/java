package ��������;

public class Under extends Student{
	private String circle; // ���Ƹ�
	
	public Under(String name, int grade, String professorName,String address, String circle) {
		super(name, grade, professorName, address);
		this.circle = circle;
		
	}

	public void ChangeCircle(String newCircle)throws MyException
	{
		if(newCircle.equals(""))
		{
			throw new MyException(-200,"Circle Name - Empty Error");
		}
		else{
		circle = newCircle;
		}
	}
	
	public void show()
	{
		System.out.print("���� : �к�, ");
		super.show();
		System.out.print(", ���Ƹ� : " + circle);
	}
}
