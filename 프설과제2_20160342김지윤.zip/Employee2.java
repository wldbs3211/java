package ��������;

class Employee2 implements Employee
{
	public String name;
	public String company; //ȸ��
	public String department; //�μ�
	public String position; //��å
	
	
	public Employee2(String name,String company,String department,String position)
	{
		this.name=name;
		this.company=company;
		this.department=department;
		this.position=position;
	}
	public void show()
	{
		System.out.print("���� : "+name+", ȸ�� : "+company+", �μ� : "+department+", ��å : "+position);
		
	}

	@Override
	public void changePosition(String newPosition) throws MyException {
		if (newPosition.equals("")) {
			throw new MyException(-300, "Position Name - Empty Error");
		} else {
			position=newPosition;
		}
	}
}
